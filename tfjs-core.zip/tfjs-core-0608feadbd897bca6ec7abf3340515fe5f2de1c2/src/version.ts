/** @license See the LICENSE file. */

// This code is auto-generated, do not modify this file!
const version = '0.4.0';
export {version};
